package com.example.mycalc

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val num1 = findViewById<EditText>(R.id.number1)
        val num2 = findViewById<EditText>(R.id.number2)
        val add = findViewById<Button>(R.id.button1)
        val sub = findViewById<Button>(R.id.button2)
        val mul = findViewById<Button>(R.id.button3)
        val div = findViewById<Button>(R.id.button4)

        val result = findViewById<TextView>(R.id.result)

        add.setOnClickListener {
            addNum(num1,num2, result)
        }

        sub.setOnClickListener {
            subNum(num1,num2, result)
        }

        mul.setOnClickListener {
            mulNum(num1,num2, result)
        }

        div.setOnClickListener {
            divNum(num1,num2, result)
        }
    }

    fun addNum(num1: EditText, num2: EditText, result: TextView) {
        val number1 = num1.text.toString()
        val number2 = num2.text.toString()

        // Convert the text to floats and format the result
        if (number1.isNotEmpty() && number2.isNotEmpty()) {
            val sum = number1.toFloat() + number2.toFloat()
            result.text = if (sum % 1 == 0f) {
                String.format("%.0f", sum)
            } else {
                String.format("%.2f", sum)
            }
        } else {
            result.text = "Error"
        }
    }

    fun subNum(num1: EditText, num2: EditText, result: TextView) {
        val number1 = num1.text.toString()
        val number2 = num2.text.toString()

        // Convert the text to floats and format the result
        if (number1.isNotEmpty() && number2.isNotEmpty()) {
            val diff = number1.toFloat() - number2.toFloat()
            result.text = if (diff % 1 == 0f) {
                String.format("%.0f", diff)
            } else {
                String.format("%.2f", diff)
            }
        } else {
            result.text = "Error"
        }
    }

    fun mulNum(num1: EditText, num2: EditText, result: TextView) {
        val number1 = num1.text.toString()
        val number2 = num2.text.toString()

        // Convert the text to floats and format the result
        if (number1.isNotEmpty() && number2.isNotEmpty()) {
            val prod = number1.toFloat() * number2.toFloat()
            result.text = if (prod % 1 == 0f) {
                String.format("%.0f", prod)
            } else {
                String.format("%.2f", prod)
            }
        } else {
            result.text = "Error"
        }
    }

    fun divNum(num1: EditText, num2: EditText, result: TextView) {
        val number1 = num1.text.toString()
        val number2 = num2.text.toString()

        // Convert the text to floats and format the result
        if (number1.isNotEmpty() && number2.isNotEmpty()) {
            if (number2.toFloat() != 0f) {
                val quot = number1.toFloat() / number2.toFloat()
                result.text = if (quot % 1 == 0f) {
                    String.format("%.0f", quot)
                } else {
                    String.format("%.2f", quot)
                }
            } else {
                result.text = "Error"
            }
        } else {
            result.text = "Error"
        }
    }
}